// Keep Russian prepositions with their complement, including across authored soft line breaks.
const preps='без|безо|близ|в|во|вдоль|вместо|вне|внутри|вокруг|возле|вопреки|вследствие|для|до|за|из|изо|из-за|из-под|к|ко|кроме|меж|между|мимо|на|над|надо|насчёт|о|об|обо|около|от|ото|перед|передо|по|под|подо|помимо|после|посредством|при|про|против|ради|с|со|сверх|сквозь|согласно|среди|у|через';
const connectors='и|а|но|не|как|или|либо|что|чтобы|если|чем|ведь|да|ни|уж';
const prepBreak=new RegExp('(?<![\\p{L}\\p{N}_-])('+preps+'|'+connectors+')[ \\u00a0]*\\n(?=\\S)','giu');
const bound=new RegExp('(?<![\\p{L}\\p{N}_-])('+preps+'|'+connectors+')[ \\t]+(?=\\S)','giu');
export function shortWords(value){return String(value).replace(prepBreak,'\n$1\u00a0').replace(bound,'$1\u00a0');}
