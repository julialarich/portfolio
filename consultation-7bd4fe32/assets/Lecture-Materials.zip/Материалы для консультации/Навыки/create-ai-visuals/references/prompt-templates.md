# Шаблоны и рабочие примеры

Содержание: универсальное описание; фотореалистичный портрет; стилизованная 3D-голова; анимация; постер; предметный визуал; точечная правка; серия.

Все примеры ниже — адаптированные шаблоны, а не дословные цитаты источников. Заполняй только значимые поля; перед выдачей готового промпта замени скобки. Не называй текстовый пример выполненной генерацией.

## Универсальное описание

```text
Create [output type] showing [subject, defining features, action, expression].
Visual direction: [dominant aesthetic and concrete traits].
Framing and camera: [shot size, height, angle, subject orientation].
Composition: [placement, crop, foreground, reserved space].
Environment: [background and meaningful context].
Lighting: [key direction, softness, fill, shadow character].
Materials: [surface properties and selected texture details].
Color and finish: [palette, contrast, processing].
Preserve: [reference-dependent features and exact requirements].
Avoid: [short list of relevant defects].
```

Соотношение сторон и настройки сервиса укажи отдельно, если инструмент предоставляет соответствующие поля.

## Фотореалистичный портрет

```text
Create a natural photographic head-and-shoulders portrait of the person
in the supplied identity reference. Preserve the facial proportions,
hairstyle and distinctive features. Eye-level camera, three-quarter
head orientation, gaze toward the camera. Soft directional window light
from camera left and gentle fill from the opposite side. Preserve
natural skin microtexture, subtle local variations in tone and sheen,
individual eyebrow hairs and realistic eye moisture. Keep both eyes
sharp with a gradual transition to a quiet background. Neutral skin
color, balanced contrast and a restrained photographic finish.
Avoid waxy smoothing, duplicated features and sharpening halos.
```

Если референса нет, замени инструкцию о сходстве конкретным описанием героя. Не добавляй особенности внешности наугад.

## Стилизованная 3D-голова

```text
Create a stylized 3D floating head using the supplied portrait for
identity and the supplied style reference for rendering treatment.
Preserve the person's recognizable facial proportions. Front-facing,
centered composition with the full hairstyle visible. Slicked-back
hair, a restrained annoyed expression and closed lips. No bubble is
present in this starting frame. Smooth vinyl-like skin with controlled
gloss, glassy eyes and soft studio lighting. Clean white background.
Only the head is visible; keep the silhouette clear and the image
suitable as the starting frame for a short animation.
```

«Винил», эмоция и причёска здесь относятся к примеру. Измени их по брифу. Не прикладывай к этому варианту отрицание CGI или plastic skin.

## Анимация подготовленной головы

```text
Animate the provided starting image. Keep the camera locked and the
head centered at a stable scale. First, show subtle chewing with small
lip movements and one soft blink. Then a small pink gum bubble emerges
from the lips and slowly grows into a round glossy shape. At the end,
the bubble pops and the lips settle. Preserve facial identity,
hairstyle, accessories, vinyl material and the lighting throughout.
Allow only a slight head sway. Keep the white background steady.
```

Применяй только к стартовому кадру без пузыря. Для кадра с пузырём перепиши начало: «The existing bubble slowly expands…». Длительность выбирай по задаче и доступным настройкам.

## Постер с сочетанием эстетик

```text
Create a speculative event-poster background.
Dominant aesthetic: Liminal Space.
Secondary aesthetic: Acid Graphics, limited to the central object
and graphic accents.
ERA: a late-night interior with 1990s digital-design accents.
MATERIAL: worn carpet, concrete, fluorescent fixtures, one liquid-chrome
sculpture and restrained acid-color details.
MOOD: empty, strange and tense.
TECH: everyday architecture with a visibly artificial central object.
Camera: eye level, straight horizon, deep corridor perspective.
Composition: one focal object below center, clear space across the
upper quarter for a separately typeset headline.
Do not add lettering to the background.
```

Если пользователь просит надпись внутри изображения, замени последнюю инструкцию точным текстом. Для редактируемого макета добавь надписи отдельными слоями в инструменте вёрстки.

## Предметный визуал

```text
Create a photographic product image of [product], preserving its shape,
proportions, colors and visible construction from the reference.
Use a three-quarter view at [camera height], with the full product in
frame. Place it on [surface] in [environment]. Use a large directional
key light from [direction] and soft fill, with a plausible contact shadow.
Show [material-specific texture and reflection behavior].
Keep [important product details] sharp. Reserve [area] for copy.
```

Для утверждённого логотипа или этикетки используй исходный материал и проверь текст. Не реконструируй обязательные надписи «по смыслу».

## Точечная правка

```text
Edit the supplied image. Change only [specific property or region].
Keep [identity, pose, framing, background, lighting, colors, text]
unchanged. The corrected area should show [concrete desired result]
and match the existing image in scale, perspective and light.
```

При противоречии между правкой и списком сохранений уточни или скорректируй формулировку. Например, изменение ракурса всего кадра обычно требует пересборки перспективы, поэтому нельзя одновременно обещать неизменность всех пикселей.

## Серия

Сначала зафиксируй общую спецификацию героя, материала, света, обработки и формата. Затем создай таблицу: кадр → действие → крупность → ракурс → изменяемые детали. Для каждого кадра используй общие признаки и только его локальные различия.
